#ifndef SERVO_H
#define SERVO_H

#include "stm32l476xx.h"
#include <stdint.h>

void Servo_Init(void);
void Servo_SetAngle(uint8_t angle);

#endif
