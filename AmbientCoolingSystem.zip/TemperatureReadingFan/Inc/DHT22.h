/*
 * DHT22.h
 *
 * Header file for DHT22 temperature & humidity sensor
 * Target MCU: STM32L476 (register-level programming)
 *
 * This file provides:
 *   - Pin definitions (D7 / PA8)
 *   - Function prototypes (used in main.c)
 *   - Shared variables (Temperature & Humidity)
 *
 * The actual implementation is in DHT22.c
 */

#ifndef __DHT22_H
#define __DHT22_H

#include "stm32l476xx.h"
#include <stdint.h>

/* ----------------------------------------------------
 * DHT22 Pin Configuration
 *
 * The DHT22 DATA pin is connected to D7.
 *
 * On most STM32 Nucleo boards:
 *      D7 = PA8
 *
 * We define:
 *   - DHT_PORT = GPIOA
 *   - DHT_PIN  = 8
 * ---------------------------------------------------- */
#define DHT_PORT GPIOC
#define DHT_PIN  0

/* ----------------------------------------------------
 * Shared Sensor Values
 *
 * These variables are updated every time DHT_Display()
 * reads the sensor successfully.
 *
 * They can also be accessed from main.c if needed.
 * ---------------------------------------------------- */

/* Temperature in degrees Celsius */
extern float Temperature;

/* Relative humidity in percent (%) */
extern float Humidity;

/* ----------------------------------------------------
 * Function Prototypes
 *
 * These functions are implemented in DHT22.c
 * ---------------------------------------------------- */

/*
 * DWT_Delay_Init()
 *
 * Initializes the DWT (Data Watchpoint and Trace) unit
 * to enable microsecond timing using the CPU cycle counter.
 *
 * Must be called once in main() before using delay_us().
 */
void DWT_Delay_Init(void);

/*
 * delay_us()
 *
 * Creates a blocking delay in microseconds.
 *
 * NOTE:
 * This version assumes the system clock is 16 MHz (HSI).
 */
void delay_us(uint32_t us);

/*
 * DHT_SetPinInput()
 *
 * Configures the DHT22 data pin (PA8) as:
 *   - Input mode
 *   - Pull-up enabled
 *
 * This is the idle state of the DHT22 communication line.
 */
void DHT_SetPinInput(void);

/*
 * DHT_Display()
 *
 * Main function that:
 *   1. Communicates with the DHT22 sensor
 *   2. Reads temperature and humidity
 *   3. Converts raw data to real values
 *   4. Displays results on the LCD
 */
void DHT_Display(void);

#endif /* __DHT22_H */
