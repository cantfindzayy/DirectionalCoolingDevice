/*
 * DHT11.c
 *
 *  Created on: May 1, 2026
 *      Author: Magee
 */

#include "stm32l476xx.h"
#include <stdio.h>
#include "core_cm4.h"

#define PB6       6

void configure_PB6(){
  // 1. Enable the clock to GPIO Port B
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;

	// 2. Configure GPIO Mode to 'Alternative Function' mode: Input(00), Output(01), Alternative Function(10), Analog(11)
	GPIOB->MODER &= ~(0b11<<(2*PB6));
	GPIOB->MODER |=   0b01<<(2*PB6);

	// 3. Select PA1's alternative function as TIM4_CH1, which is 'AF2', by configuring the GPIOA_AFRL register
	GPIOB->AFR[0] &= ~(0b1111 << (4*PB6));
	GPIOB->AFR[0] |= (0b0010 << (4*PB6));

	GPIOB->OTYPER &= ~(1 << PB6);
	GPIOB->OTYPER |= (1 << PB6);

	GPIOB->PUPDR &= ~(0b0011 << (2*PB6));
	GPIOB->PUPDR |= (1 << (2*PB6));

}


void TIM4_CH1_Init(void) {//pb6 echo

	//1. Enable the clock to TIM4 by configuring RCC_APB1ENR1 register
	RCC->APB1ENR1 |= RCC_APB1ENR1_TIM4EN;

	//2. Configure TIM4 counting mode to upcounting (TIMx_CR1)
	TIM4->CR1 &= ~TIM_CR1_DIR;

	//3. Configure TIM4 Prescalar (TIMx_PSC) and ARR (TIMx_ARR) to generate a desired counter period
	TIM4->PSC = CNT_PSC-1;		// Set up an appropriate prescaler to slow down the clock or timer counter
	TIM4->ARR = 10000-1;

	//4. Configure TIMx_CCMR1 CC1S[1:0] bits for TIM4 Channel 1
	//   to set the Capture/Compare channel direction as input,
	//   and input channel (CC1) is mapped on Timer Input 1 (TI1)
	//   00 = output
	//   01 = input, CC1 is mapped on timer Input 1 (TI1)
	//   10 = input, CC1 is mapped on timer Input 2 (TI2)
	//   11 = input, CC1 is mapped on slave timer
	TIM4->CCMR1 &= ~TIM_CCMR1_CC1S;
	TIM4->CCMR1 |= TIM_CCMR1_CC1S_0;

	// 5. Disable digital filtering by configuring TIMx_CCMR1 IC1F[3:0] bits
	//    because we want to capture every event
	TIM4->CCMR1 &= ~TIM_CCMR1_IC1F;

	// 6. Program the input prescaler by configuring TIMx_CCMR1 IC1PSC[1:0] bits
	// To capture each valid transition, set the input prescaler to zero;
	TIM4->CCMR1 &= ~(TIM_CCMR1_IC1PSC); // Clear filtering because we need to capture every event

	// 7. Select the active edge(s) for trigger of input capture operaiton
	//    by configuring TIMx_CCER CC1NP and CC1P bits
	// CC1NP=0, CC1P=0: rising edge,
	// CC1NP=0, CC1P=1: falling edge,
	// CC1NP=1, CC1P=0: reserved,
	// CC1NP=1, CC1P=1: both edges
	TIM4->CCER |= (TIM_CCER_CC1NP | TIM_CCER_CC1P);		// Both rising and falling edges.

	// 8. Enable Input Capture mode by setting TIMx_CCER CC1E bit
	TIM4->CCER |= TIM_CCER_CC1E;

	// 9. Enable related interrupts by
	//		i. configuring TIMx_DIER register
	TIM4->DIER |= TIM_DIER_CC1IE;		// Enable Capture/Compare interrupts for channel 1
	TIM4->DIER |= TIM_DIER_UIE;			// Enable update interrupts

	//    ii. enable TIM4 interrupt source in NVIC
	NVIC_EnableIRQ(TIM4_IRQn);      // Enable TIM4 interrupt in NVIC

	//10. Set TIMx_CR1 CEN bit to enable the TIM4 counter
	TIM4->CR1 |= TIM_CR1_CEN;				// Enable the counter
}

//TIM4 ISR
void TIM4_IRQHandler(void) {

	if((TIM4->SR & TIM_SR_UIF) == TIM_SR_UIF) {	// Check if counter overflow interrupt is triggered
											// If overflow occurred, increment overflow counter
	}

	// Check if input capture interrupt is triggered
	if((TIM4->SR & TIM_SR_CC1IF) == TIM_SR_CC1IF) {

	}
}
