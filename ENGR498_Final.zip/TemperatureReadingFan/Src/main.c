#include "stm32l476xx.h"
#include <stdio.h>
#include "core_cm4.h"

#define

int main(void) {


	while(1) {

	}
}
