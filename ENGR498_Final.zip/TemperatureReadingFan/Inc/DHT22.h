/*
 * DHT11.h
 *
 *  Created on: May 1, 2026
 *      Author: Magee
 */

#ifndef DHT22_H_
#define DHT22_H_

void configure_PB6();

void TIM4_CH1_Init(void);

void turn_on_DHT11();

void turn_off_DHT11();

void toggle_DHT11();

#endif /* DHT22_H_ */
